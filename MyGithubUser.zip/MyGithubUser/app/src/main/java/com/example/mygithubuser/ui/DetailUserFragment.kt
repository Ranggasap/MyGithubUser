package com.example.mygithubuser.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.StringRes
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.mygithubuser.R
import com.example.mygithubuser.adapter.SectionsPagerAdapter
import com.example.mygithubuser.databinding.FragmentDetailUserBinding
import com.example.mygithubuser.viewModel.DetailUserViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailUserFragment : Fragment() {

    private var _binding: FragmentDetailUserBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DetailUserViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentDetailUserBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val dataUsername = DetailUserFragmentArgs.fromBundle(arguments as Bundle).username
        val dataAvatarUrl = DetailUserFragmentArgs.fromBundle(arguments as Bundle).avatarUrl

        if(viewModel.username.value != dataUsername || viewModel.username.value == null){
            viewModel.setUsername(dataUsername)
        }

        viewModel.detailUser.observe(viewLifecycleOwner){userDetail ->
            setTotalFollower(userDetail.followers)
            setTotalFollowing(userDetail.following)
            setDetailUser(userDetail.login, userDetail.avatarUrl, userDetail.name)
        }

        val sectionsPagerAdapter = SectionsPagerAdapter(requireActivity())
        sectionsPagerAdapter.username = dataUsername
        val viewPager2: ViewPager2 = binding.viewPager
        viewPager2.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager2) {tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        viewModel.isLoading.observe(viewLifecycleOwner){isLoading ->
            showLoading(isLoading)
        }
    }

    private fun setTotalFollower(totalFollower: Int){
        binding.tvFollower.text = "$totalFollower Followers"
    }

    private fun setTotalFollowing(totalFollowing: Int){
        binding.tvFollowing.text = "$totalFollowing Following"
    }

    private fun setDetailUser(dataUsername: String, dataAvatarUrl: String, dataName: String){
        binding.tvUsername.text = dataUsername
        Glide.with(binding.root.context)
            .load(dataAvatarUrl)
            .into(binding.ciUserAvatar)
        binding.tvName.text = dataName
        binding.tvFollower.visibility = View.VISIBLE
        binding.tvFollowing.visibility = View.VISIBLE
        binding.tvUsername.visibility = View.VISIBLE
        binding.tvName.visibility = View.VISIBLE
    }

    private fun showLoading(isLoading: Boolean){
        if(isLoading){
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object{
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.follower_tab,
            R.string.following_tab
        )
    }
}
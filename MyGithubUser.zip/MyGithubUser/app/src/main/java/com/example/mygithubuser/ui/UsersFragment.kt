package com.example.mygithubuser.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mygithubuser.adapter.UsersAdapter
import com.example.mygithubuser.data.response.ItemsItem
import com.example.mygithubuser.databinding.FragmentUsersBinding
import com.example.mygithubuser.viewModel.UsersViewModel
import com.google.android.material.snackbar.Snackbar

class UsersFragment : Fragment() {

    private var _binding: FragmentUsersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: UsersViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentUsersBinding.inflate(inflater, container, false)
        val view = binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.listUsers.observe(viewLifecycleOwner){listUsers ->
            setUsersData(listUsers)
        }

        viewModel.snackbarText.observe(viewLifecycleOwner){
            it.getContentIfNotHandled()?.let{snackbarText ->
                Snackbar.make(
                    requireActivity().window.decorView.rootView,
                    snackbarText,
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }

        with(binding){
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener{textView, actionId, event ->
                    searchBar.text = searchView.text
                    searchView.hide()
                    viewModel.searchUsername(searchView.text.toString())
                    false
                }
        }

        val layoutManager = LinearLayoutManager(requireActivity())
        binding.recyclerView.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireActivity(), layoutManager.orientation)
        binding.recyclerView.addItemDecoration(itemDecoration)


        viewModel.isLoading.observe(viewLifecycleOwner){isLoading ->
            showLoading(isLoading)
        }
    }

    private fun setUsersData(usersData: List<ItemsItem>){
        val adapter = UsersAdapter()
        adapter.submitList(usersData)
        binding.recyclerView.adapter = adapter

        adapter.setOnItemClickCallback(object : UsersAdapter.OnItemClickCallback{
            override fun onItemClicked(user: ItemsItem) {
                val toDetailUserFragment = UsersFragmentDirections.actionUsersFragmentToDetailUserFragment()
                toDetailUserFragment.username = user.login
                toDetailUserFragment.avatarUrl = user.avatarUrl
                view?.findNavController()?.navigate(toDetailUserFragment)
            }
        })
    }

    private fun showLoading(isLoading: Boolean){
        if(isLoading){
            binding.progressBar.visibility = View.VISIBLE
        }else{
            binding.progressBar.visibility = View.GONE
        }
    }
}